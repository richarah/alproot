The fakechroot project was started as dirty hack because I've got an access
to some system without root privileges. I really wanted to install additional
software and I imagined that no access to the root account should be no
problem at all.

For years, more and more people started to use the fakechroot.

I would like to thank to:

* Marcin Jakubowski, for an inspiration
* Joost Witteveen, for his fakeroot
* Lionel Tricon, for an exclude path list feature
* Mark Eichin, for countless patches with bugfixes
* Martin Pitt, for great Ubuntu support
* Daniel Kahn Gillmor, for testing

And to contributors (alphabetically):

* Andreas Jochens
* Andrew Gregory
* Brian Silverman
* Christopher Meng
* Colin Watson
* Daniel Kahn Gillmor
* Daniel Tschan
* Geert Stappers
* Guido Günther
* JH Chatenet
* Johannes Schauer
* Juan Romero Pardines
* Kurt Roeckx
* Lucas Nussbaum
* Luk Claes
* Marc 'HE' Brockschmidt
* Mario Iseli
* Martin von Gagern
* Oleksandr Usov
* Raúl Sánchez Siles
* Robert Blair Mason Jr.
* Robert Spanton
* Robin McCorkell
* Santiago Vila
* Sune Vuorela
* Sven Ulland
